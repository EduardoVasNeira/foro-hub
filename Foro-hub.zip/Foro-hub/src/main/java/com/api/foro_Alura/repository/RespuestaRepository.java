package com.api.foro_Alura.repository;

import com.api.foro_Alura.model.Respuesta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RespuestaRepository extends JpaRepository<Respuesta, Long> {
}
